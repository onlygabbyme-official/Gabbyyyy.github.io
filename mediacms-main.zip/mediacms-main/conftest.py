from pytest_factoryboy import register

from tests.users.factories import UserFactory

register(UserFactory)

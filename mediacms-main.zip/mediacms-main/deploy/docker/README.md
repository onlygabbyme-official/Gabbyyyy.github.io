# MediaCMS on Docker

See: [Details](../../docs/Docker_deployment.md)

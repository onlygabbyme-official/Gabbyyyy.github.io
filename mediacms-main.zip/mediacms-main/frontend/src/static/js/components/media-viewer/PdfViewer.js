import React from 'react';

export default function PdfViewer() {
  return (
    <div className="player-container viewer-pdf-container">
      <div className="player-container-inner">
        <span>
          <span>
            <i className="material-icons">insert_drive_file</i>
          </span>
        </span>
      </div>
    </div>
  );
}
